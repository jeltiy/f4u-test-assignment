<?php

use Symfony\Component\Routing\Matcher\Dumper\PhpMatcherTrait;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcApp_KernelDevDebugContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    use PhpMatcherTrait;

    public function __construct(RequestContext $context)
    {
        $this->context = $context;
        $this->staticRoutes = array(
            '/api/security/login' => array(array(array('_route' => 'login', '_controller' => 'App\\Controller\\ApiSecurityController::loginAction'), null, null, null, false, null)),
            '/api/security/updateProfile' => array(array(array('_route' => 'updateProfile', '_controller' => 'App\\Controller\\ApiSecurityController::updateAction'), null, null, null, false, null)),
            '/api/shipping_addresses/create' => array(array(array('_route' => 'createShippingAddress', '_controller' => 'App\\Controller\\ApiShippingAddressController::createAction'), null, array('POST' => 0), null, false, null)),
            '/api/shipping_addresses' => array(array(array('_route' => 'getAllShippingAddresses', '_controller' => 'App\\Controller\\ApiShippingAddressController::getAllActions'), null, array('GET' => 0), null, false, null)),
            '/_profiler' => array(array(array('_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'), null, null, null, true, null)),
            '/_profiler/search' => array(array(array('_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'), null, null, null, false, null)),
            '/_profiler/search_bar' => array(array(array('_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'), null, null, null, false, null)),
            '/_profiler/phpinfo' => array(array(array('_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'), null, null, null, false, null)),
            '/_profiler/open' => array(array(array('_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'), null, null, null, false, null)),
        );
        $this->regexpList = array(
            0 => '{^(?'
                    .'|/api/shipping_addresses/([^/]++)/(?'
                        .'|update(*:49)'
                        .'|make_default(*:68)'
                        .'|delete(*:81)'
                    .')'
                    .'|/((?!api|_(?:profiler|wdt)).*)(*:119)'
                    .'|/_(?'
                        .'|error/(\\d+)(?:\\.([^/]++))?(*:158)'
                        .'|wdt/([^/]++)(*:178)'
                        .'|profiler/([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:224)'
                                .'|router(*:238)'
                                .'|exception(?'
                                    .'|(*:258)'
                                    .'|\\.css(*:271)'
                                .')'
                            .')'
                            .'|(*:281)'
                        .')'
                    .')'
                .')(?:/?)$}sDu',
        );
        $this->dynamicRoutes = array(
            49 => array(array(array('_route' => 'updateShippingAddress', '_controller' => 'App\\Controller\\ApiShippingAddressController::updateAction'), array('id'), array('POST' => 0), null, false, null)),
            68 => array(array(array('_route' => 'makeDefaultShippingAddress', '_controller' => 'App\\Controller\\ApiShippingAddressController::makeDefault'), array('id'), array('POST' => 0), null, false, null)),
            81 => array(array(array('_route' => 'deleteShippingAddress', '_controller' => 'App\\Controller\\ApiShippingAddressController::delete'), array('id'), array('POST' => 0), null, false, null)),
            119 => array(array(array('_route' => 'index', '_controller' => 'App\\Controller\\IndexController::indexAction'), array('vueRouting'), null, null, false, null)),
            158 => array(array(array('_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code', '_format'), null, null, false, null)),
            178 => array(array(array('_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'), array('token'), null, null, false, null)),
            224 => array(array(array('_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array('token'), null, null, false, null)),
            238 => array(array(array('_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'), array('token'), null, null, false, null)),
            258 => array(array(array('_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception::showAction'), array('token'), null, null, false, null)),
            271 => array(array(array('_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception::cssAction'), array('token'), null, null, false, null)),
            281 => array(array(array('_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'), array('token'), null, null, false, null)),
        );
    }
}
