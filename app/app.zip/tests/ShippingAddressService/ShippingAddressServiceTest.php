<?php

use App\Entity\Client;
use App\Entity\ShippingAddress;
use App\Service\ShippingAddressService;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ShippingAddressServiceTest extends WebTestCase
{

    public function testCreateShippingAddress()
    {
        self::bootKernel();

        // returns the real and unchanged service container
        $container = self::$kernel->getContainer();

        // gets the special container that allows fetching private services
        $container = self::$container;

        $user = self::$container->get('doctrine')->getRepository(ShippingAddress::class)->findOneBy(['id' => 1]);
        $this->assertTrue(self::$container->get('App\Service\ShippingAddressService')->createShippingAddress(
            'Latvia', 'dsad', 'dasdsad', 'dasdasd', 1
        ));
    }

}